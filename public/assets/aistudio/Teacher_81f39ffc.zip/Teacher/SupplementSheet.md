# SupplementSheet (Teacher Page)

Design spec for the **SupplementSheet** frame of the InvEx Figma file.

- **Figma file:** InvEx (`UPA9x8osa59kxcwCNlfAAh`)
- **Node:** `512:124` (Teacher Page > SupplementSheet)
- **Link:** https://www.figma.com/design/UPA9x8osa59kxcwCNlfAAh/InvEx?node-id=512-124
- **Purpose:** Teacher-facing mobile screen for tracking supplementary answer sheets: summary counts, a button to issue a new sheet, and a searchable list of students who were issued sheets.

---

## 1. Frame

| Property | Value |
|---|---|
| Size | 390 x 844 (mobile) |
| Background | `MobileBackground` `#ebebeb` |
| Border | 1px `OutlineShadow` `#e8e8e8` |
| Corner radius | 15px |
| Layout | Vertical stack, 24px gap |
| Padding | 60px top, 16px sides, 24px bottom |

---

## 2. Design Tokens

| Token | Value | Used for |
|---|---|---|
| `MobileBackground` | `#ebebeb` | Screen background |
| `OutlineShadow` | `#e8e8e8` | Borders on frame, cards, rows |
| `HoverSelect` | `#f5f5f5` | Status card fill |
| `TableRowInteraction` | `#fafafa` | Search bar and student row fill |
| `orange` | `#ed451f` | Issue button fill, heading icon fill |
| `SoftWhite` | `#f7f9f7` | Text on the orange button |
| `IconColor` | `#171717` | Heading text |

Status dot colors (hard-coded in Figma, not variables): green `#66cd4c`, yellow `#ffde7c`, red `#f24e51`, teal `#4ef2d1`. Each dot has a 1px black border and 4px radius.

---

## 3. Typography

| Use | Font | Weight | Size / Line height |
|---|---|---|---|
| Page heading ("Supplements") | Pixelify Sans | SemiBold | 36 / 40, underlined |
| Section heading ("Sheets Issued") | Inter | SemiBold | 26 / 32 |
| Issue button label | Inter | SemiBold | 18 / 32 |
| Status card label | Inter | SemiBold | 14 / 14 |
| Status card count | Inter | SemiBold | 24 / 24 |
| Search placeholder, student name | Inter | Medium | 16 / normal |
| Row count | Inter | Medium | 20 / normal |
| Row meta (course, year, roll) | Inter | Medium | 10 / normal |
| "Resolved" pill text | Inter | Medium | 8 / 8 |

---

## 4. Layout Structure

```
SupplementSheet (512:124)
├── back icon and heading (507:307)
│   ├── chevron back (345:92)            30x30
│   └── icon and Heading (507:306)
│       ├── SupplementSheetIcon (375:87)  40x40, orange circle
│       └── Heading (391:89)              "Supplements"
├── PassesStatusCard (512:93)            332 wide, 16px gap
│   ├── issued and awaiting (512:91)
│   │   ├── Sheet_Issued (342:102)
│   │   └── Awaiting_Return (342:97)
│   └── returned and in stock (512:92)
│       ├── Returned (342:92)
│       └── Sheet_in_Stock (342:107)
├── IssuePass (342:112)                  358x60 button
│   ├── CirclePlus (342:115)              50x50 icon
│   └── "Issue a Supplementary Sheet"
└── Students Heading and Data (508:53)   354 wide, 12px gap
    ├── "Sheets Issued" (318:44)
    └── Student data (507:310)            18px gap
        ├── Search Inbox (353:159)
        └── row Selection (507:309)       12px gap
            ├── Row One (353:165)
            ├── Row Second (353:172)
            └── Row Third (353:179)
```

---

## 5. Components

### 5.1 Header (back icon and heading)

- Horizontal row, 4px gap, vertically centered.
- **Chevron back:** 30x30 icon, tap target to go back.
- **Icon + heading:** 8px gap.
  - Icon: 40x40 circle (25px radius), `orange` fill, white stack-of-sheets glyph.
  - Heading: "Supplements" in Pixelify Sans SemiBold 36px, `IconColor`, underlined.

### 5.2 Status cards (PassesStatusCard)

A 2x2 grid, 332px wide. Rows are 70px tall with 16px vertical gap; the two cards in a row are 150px wide with 32px between them.

Each card:
- 150x70, `HoverSelect` fill, 1px `OutlineShadow` border, 10px radius.
- 10x10 status dot at (16, 10).
- Label at left 30px, 14px SemiBold, `#0d0d0d`.
- Count at left 16px, 24px SemiBold, black.

| Card | Label | Dot color | Sample count |
|---|---|---|---|
| Sheet_Issued | Sheet Issued | Green `#66cd4c` | 01 |
| Awaiting_Return | Awaiting Return | Yellow `#ffde7c` | 15 |
| Returned | Returned | Red `#f24e51` | 01 |
| Sheet_in_Stock | Sheets in stock | Teal `#4ef2d1` | 01 |

### 5.3 Issue button (IssuePass)

- 358x60, `orange` fill, 1px `OutlineShadow` border, 15px radius.
- Padding 20px horizontal, 5px vertical; 16px gap; content vertically centered.
- Leading 50x50 CirclePlus icon (white circle with orange plus).
- Label: "Issue a Supplementary Sheet", Inter SemiBold 18px, `SoftWhite`.
- Interactive: primary action that starts issuing a new supplementary sheet.

### 5.4 Sheets Issued section

- Heading "Sheets Issued", Inter SemiBold 26px, `#040404`.
- 12px gap between heading and content; 18px gap between search bar and rows.

**Search bar (Search Inbox)**
- Full width (354), 55px tall, `TableRowInteraction` fill, 1px `OutlineShadow` border, 15px radius.
- Left padding 12px, 12px gap, magnifying-glass icon (34x34).
- Placeholder: "Search for the students", Inter Medium 16px, black.
- Interactive: text input that filters the list.

**Student row (Row One / Second / Third)**
- Full width, 55px tall, 12px vertical gap between rows.
- Background card: `TableRowInteraction` fill, 1px `OutlineShadow` border, 15px radius.
- Content positions inside the row:

| Element | Position | Style | Sample text |
|---|---|---|---|
| Student name | left 18, top 9 | Inter Medium 16 | Lorem Ipsum Dorem |
| Meta line | left 18, top 36 | Inter Medium 10 | B.tech \| 3rd Year \| 7045 |
| Sheet count | left 316, top 7 | Inter Medium 20 | 01 |
| Status pill | left 286, top 33, 60x15 | `#d9d9d9` fill, 15px radius | Resolved |
| Pill text | left 299, top 37 | Inter Medium 8 | Resolved |

The design shows three placeholder rows with identical content. Real data should supply name, course/year/roll number, number of sheets issued, and a status (only "Resolved" is shown in the design).

---

## 6. Assets

Four SVG assets are used. Download them from Figma before building, since the MCP URLs are temporary and expire after 7 days.

| Asset | Location | Size |
|---|---|---|
| Chevron back | Header | 30x30 |
| Supplement sheet icon (stacked sheets, white) | Header icon circle | 40x40 container |
| CirclePlus | Issue button | 50x50 |
| Search magnifier | Search bar | 34x34 |

---

## 7. Behavior Notes (inferred from the design)

- Chevron navigates back to the Teacher home.
- "Issue a Supplementary Sheet" opens the issue flow.
- The search bar filters the student list by name or details.
- Status counts at the top summarize the sheet lifecycle: issued, awaiting return, returned, in stock.
- Only the "Resolved" row state is designed; other states (for example pending) are not shown in this frame.

---

## 8. Observations

- Row background rectangles are 358px wide inside a 354px container, so they overflow by 4px. Likely a Figma sizing quirk worth normalizing to full width when built.
- The Issue button is 358px wide while the status cards container is 332px and the student section is 354px, so horizontal alignment is not perfectly consistent across sections.
- Status dot colors are not tokenized; consider adding variables.
