package com.invex.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.invex.app.supplement.SupplementSheetRoute
import com.invex.app.ui.theme.InvexTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            InvexTheme {
                // No navigation yet: wire these up when you add more screens.
                SupplementSheetRoute(
                    onBack = { finish() },
                    onIssueSheet = { /* TODO: open issue flow */ },
                )
            }
        }
    }
}
