package com.invex.app.supplement

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class SupplementUiState(
    val summary: SheetSummary = SheetSummary(),
    val query: String = "",
    val allStudents: List<StudentSheet> = emptyList(),
) {
    val visibleStudents: List<StudentSheet>
        get() = if (query.isBlank()) allStudents else allStudents.filter {
            it.name.contains(query, ignoreCase = true) ||
                it.rollNumber.contains(query, ignoreCase = true) ||
                it.course.contains(query, ignoreCase = true)
        }
}

class SupplementViewModel : ViewModel() {

    // Sample data mirroring the Figma frame. Swap for a repository later.
    private val _state = MutableStateFlow(
        SupplementUiState(
            summary = SheetSummary(issued = 1, awaitingReturn = 15, returned = 1, inStock = 1),
            allStudents = List(3) { i ->
                StudentSheet(
                    id = "s$i",
                    name = "Lorem Ipsum Dorem",
                    course = "B.tech",
                    year = "3rd Year",
                    rollNumber = "7045",
                    sheetCount = 1,
                    status = SheetStatus.RESOLVED,
                )
            },
        )
    )
    val state: StateFlow<SupplementUiState> = _state.asStateFlow()

    fun onQueryChange(query: String) = _state.update { it.copy(query = query) }
}
