package com.invex.app.supplement

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.invex.app.R
import com.invex.app.ui.theme.CardLabelColor
import com.invex.app.ui.theme.HoverSelect
import com.invex.app.ui.theme.IconColor
import com.invex.app.ui.theme.InvexType
import com.invex.app.ui.theme.Orange
import com.invex.app.ui.theme.OutlineShadow
import com.invex.app.ui.theme.PillGrey
import com.invex.app.ui.theme.SoftWhite
import com.invex.app.ui.theme.TableRowInteraction

private val Hairline = BorderStroke(1.dp, OutlineShadow)

/** Chevron + orange sheet icon + underlined "Supplements" heading. */
@Composable
fun SupplementsHeader(onBack: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            painter = painterResource(R.drawable.ic_chevron_back),
            contentDescription = "Back",
            modifier = Modifier
                .size(30.dp)
                .clip(CircleShape)
                .clickable(onClick = onBack),
        )
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier.size(40.dp).clip(CircleShape).background(Orange),
                contentAlignment = Alignment.Center,
            ) {
                Image(
                    painter = painterResource(R.drawable.ic_supplement_sheet),
                    contentDescription = null,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 9.dp),
                )
            }
            Text(
                text = "Supplements",
                style = InvexType.PageHeading,
                color = IconColor,
                textDecoration = TextDecoration.Underline,
            )
        }
    }
}

/** One of the four count cards: status dot, label, big number. */
@Composable
fun StatusCard(label: String, count: Int, dotColor: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .height(70.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(HoverSelect)
            .border(Hairline, RoundedCornerShape(10.dp)),
    ) {
        Box(
            modifier = Modifier
                .padding(start = 16.dp, top = 10.dp)
                .size(10.dp)
                .background(dotColor, RoundedCornerShape(4.dp))
                .border(1.dp, Color.Black, RoundedCornerShape(4.dp)),
        )
        Text(
            text = label,
            style = InvexType.CardLabel,
            color = CardLabelColor,
            modifier = Modifier.padding(start = 30.dp, top = 8.dp),
        )
        Text(
            text = "%02d".format(count),
            style = InvexType.CardCount,
            color = Color.Black,
            modifier = Modifier.padding(start = 16.dp, top = 30.dp),
        )
    }
}

/** 2x2 grid of status cards. */
@Composable
fun StatusGrid(summary: SheetSummary, modifier: Modifier = Modifier) {
    androidx.compose.foundation.layout.Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(32.dp)) {
            StatusCard("Sheet Issued", summary.issued, com.invex.app.ui.theme.StatusGreen, Modifier.weight(1f))
            StatusCard("Awaiting Return", summary.awaitingReturn, com.invex.app.ui.theme.StatusYellow, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(32.dp)) {
            StatusCard("Returned", summary.returned, com.invex.app.ui.theme.StatusRed, Modifier.weight(1f))
            StatusCard("Sheets in stock", summary.inStock, com.invex.app.ui.theme.StatusTeal, Modifier.weight(1f))
        }
    }
}

/** Big orange primary action. */
@Composable
fun IssueSheetButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(15.dp)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(60.dp)
            .clip(shape)
            .background(Orange)
            .border(Hairline, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            painter = painterResource(R.drawable.ic_circle_plus),
            contentDescription = null,
            modifier = Modifier.size(50.dp),
        )
        Text(text = "Issue a Supplementary Sheet", style = InvexType.ButtonLabel, color = SoftWhite)
    }
}

/** Search field built from BasicTextField so Material's default TextField padding/height can't interfere. */
@Composable
fun SearchBar(query: String, onQueryChange: (String) -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(15.dp)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(55.dp)
            .clip(shape)
            .background(TableRowInteraction)
            .border(Hairline, shape)
            .padding(start = 12.dp, end = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            painter = painterResource(R.drawable.ic_search),
            contentDescription = "Search",
            modifier = Modifier.size(34.dp),
        )
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (query.isEmpty()) {
                Text("Search for the students", style = InvexType.Body16, color = Color.Black)
            }
            BasicTextField(
                value = query,
                onValueChange = onQueryChange,
                singleLine = true,
                textStyle = InvexType.Body16.copy(color = Color.Black),
                cursorBrush = SolidColor(Color.Black),
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

/** One student row: name + meta on the left, count + status pill on the right. */
@Composable
fun StudentRow(student: StudentSheet, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(15.dp)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(55.dp)
            .clip(shape)
            .background(TableRowInteraction)
            .border(Hairline, shape),
    ) {
        Text(
            text = student.name,
            style = InvexType.Body16,
            color = Color.Black,
            modifier = Modifier.padding(start = 18.dp, top = 9.dp),
        )
        Text(
            text = student.meta,
            style = InvexType.RowMeta,
            color = Color.Black,
            modifier = Modifier.padding(start = 18.dp, top = 36.dp),
        )
        Text(
            text = "%02d".format(student.sheetCount),
            style = InvexType.RowCount,
            color = Color.Black,
            modifier = Modifier.align(Alignment.TopEnd).padding(end = 15.dp, top = 7.dp),
        )
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(end = 8.dp, top = 33.dp)
                .size(width = 60.dp, height = 15.dp)
                .background(PillGrey, RoundedCornerShape(15.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Text(text = student.status.label, style = InvexType.Pill, color = Color.Black)
        }
    }
}
