package com.invex.app.supplement

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.invex.app.ui.theme.InvexTheme
import com.invex.app.ui.theme.InvexType
import com.invex.app.ui.theme.MobileBackground
import com.invex.app.ui.theme.SectionHeadingColor

/** Stateful entry point: owns the ViewModel. */
@Composable
fun SupplementSheetRoute(
    onBack: () -> Unit,
    onIssueSheet: () -> Unit,
    viewModel: SupplementViewModel = viewModel(),
) {
    val state by viewModel.state.collectAsState()
    SupplementSheetScreen(
        state = state,
        onBack = onBack,
        onIssueSheet = onIssueSheet,
        onQueryChange = viewModel::onQueryChange,
    )
}

/** Stateless screen: easy to preview and test. */
@Composable
fun SupplementSheetScreen(
    state: SupplementUiState,
    onBack: () -> Unit,
    onIssueSheet: () -> Unit,
    onQueryChange: (String) -> Unit,
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MobileBackground)
            .statusBarsPadding(),
        // The Figma frame uses 60dp top padding including its fake status bar,
        // so we use the real status bar inset plus a small gap instead.
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp),
    ) {
        item { SupplementsHeader(onBack = onBack) }
        item { StatusGrid(state.summary) }
        item { IssueSheetButton(onClick = onIssueSheet) }
        item {
            Text("Sheets Issued", style = InvexType.SectionHeading, color = SectionHeadingColor)
        }
        item { SearchBar(query = state.query, onQueryChange = onQueryChange) }
        items(state.visibleStudents, key = { it.id }) { student ->
            StudentRow(student)
        }
    }
}

@Preview(showBackground = true, widthDp = 390, heightDp = 844)
@Composable
private fun SupplementSheetPreview() {
    InvexTheme {
        SupplementSheetScreen(
            state = SupplementViewModel().state.value,
            onBack = {},
            onIssueSheet = {},
            onQueryChange = {},
        )
    }
}
