package com.invex.app.supplement

data class StudentSheet(
    val id: String,
    val name: String,
    val course: String,
    val year: String,
    val rollNumber: String,
    val sheetCount: Int,
    val status: SheetStatus,
) {
    val meta: String get() = "$course | $year | $rollNumber"
}

// Only RESOLVED is shown in the Figma frame; the others are placeholders to design later.
enum class SheetStatus(val label: String) {
    RESOLVED("Resolved"),
    PENDING("Pending"),
}

data class SheetSummary(
    val issued: Int = 0,
    val awaitingReturn: Int = 0,
    val returned: Int = 0,
    val inStock: Int = 0,
)
